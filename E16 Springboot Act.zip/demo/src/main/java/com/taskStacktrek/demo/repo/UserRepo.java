package com.taskStacktrek.demo.repo;
import com.taskStacktrek.demo.models.tasks;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo extends JpaRepository<tasks, Long> {

}
