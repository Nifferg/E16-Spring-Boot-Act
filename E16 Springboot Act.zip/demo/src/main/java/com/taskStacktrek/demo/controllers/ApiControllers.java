package com.taskStacktrek.demo.controllers;
import com.taskStacktrek.demo.models.tasks;
import com.taskStacktrek.demo.repo.UserRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.config.Task;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Optional;

@RestController
public class ApiControllers {
    @Autowired
    private UserRepo userRepo;
    @GetMapping(value = "/")
    public String getPage(){
        return "welcome";
    }
    @GetMapping(value = "/users")
    public ModelAndView getTasks() {
        List<tasks> task = userRepo.findAll();
        ModelAndView mav = new ModelAndView("index");
        mav.addObject("AllTasks", task);
        return mav;
    }

    @GetMapping("/tasks/{id}/toggle")
    public ModelAndView toggleTask(@PathVariable Long id) {
        Optional<tasks> optionalTask = userRepo.findById(id);
        if(optionalTask.isPresent()){
            tasks tasks = optionalTask.get();
            tasks.setCompleted(!tasks.isCompleted());
            userRepo.save(tasks);
        }
        ModelAndView mav = new ModelAndView("redirect:/users");
        return mav;
    }

    @GetMapping("/addnew")
    public ModelAndView addNewData() {
        tasks tasks = new tasks();
        ModelAndView mav = new ModelAndView("addtask");
        mav.addObject("tasks", tasks);
        return mav;
    }

    @PostMapping(value = "/save")
    public ModelAndView saveTasks(@ModelAttribute tasks tasks){
        userRepo.save(tasks);
        ModelAndView modelAndView = new ModelAndView("redirect:/users");
        return modelAndView;
    }

    @PutMapping(value = "update/{id}")
    public String updateTasks(@PathVariable long id, @RequestBody tasks tasks){
        tasks updatedTasks = userRepo.findById(id).get();
        updatedTasks.setTitle(tasks.getTitle());
        updatedTasks.setDescription(tasks.getDescription());
        userRepo.save(updatedTasks);
        return "updated...";

    }

    @DeleteMapping(value = "/delete/{id}")
    public String deleteTasks(@PathVariable long id){
        tasks deleteTasks = userRepo.findById(id).get();
        userRepo.delete(deleteTasks);
        return "task deleted with id: " +id;
    }






}
